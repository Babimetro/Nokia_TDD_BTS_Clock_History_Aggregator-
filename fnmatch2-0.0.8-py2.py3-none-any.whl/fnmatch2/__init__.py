# -*- coding: utf-8 -*-

from .fnmatch2 import fnmatch2
from .fnmatch2 import fnmatchcase2


__version__ = '0.0.8'
__all__ = ['fnmatch2', 'fnmatchcase2']
