An improved Unix filename pattern matching


